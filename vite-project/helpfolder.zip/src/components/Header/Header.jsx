function Header() {
  return (
    <header>
      <h1>Resans Planerings Portal</h1>
    </header>
  );
}

export default Header;
