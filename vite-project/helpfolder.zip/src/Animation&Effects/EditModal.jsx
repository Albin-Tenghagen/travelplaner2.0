function EditModal() {
  return console.log("EditModal");
}
export default EditModal;
