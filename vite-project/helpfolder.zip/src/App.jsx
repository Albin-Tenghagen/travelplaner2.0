import { useEffect, useState } from "react";
import Header from "./components/Header/Header";
import Footer from "./components/Footer/Footer";
import Main from "./components/Main/Main";
import Aside from "./components/Aside/Aside";

import "./App.css";
// * The main App component that manages activities and renders the application layout.
function App() {
  // State to store the array of activities.
  const [ActivityArray, setActivityArray] = useState([]);
  const [showNotification, setShowNotification] = useState(false);
  const [ActicityEdit, setActivityEdit] = useState(false);

  // Function to create and add a new activity to the ActivityArray
  function createActivity(newActivity) {
    // Create a new activity object with an ID (based on the current length of ActivityArray)
    const Activity = {
      id: ActivityArray.length + 1,
      name: newActivity.name,
      description: newActivity.description,
      date: newActivity.date,
      location: newActivity.location,
    };

    // Update the state with new activity
    setActivityArray([...ActivityArray, Activity]);

    console.log("Activity created", Activity);
    console.log("Array updated", ActivityArray);
  }
  const onEdit = (id) => {
    const activityToEdit = ActivityArray.find((Activity) => Activity.id === id);
    activityToEdit.description = "Alla hjärtans dag";

    const updatedActivities = ActivityArray.map((activity) =>
      activity.id === id
        ? { ...activity, description: "Alla hjärtans dag" }
        : activity
    );

    setActivityArray(updatedActivities);
    console.log(
      "onEdit function called, Activity to edit found:",
      activityToEdit
    );
    useEffect(() => {
      console.log("Nånting händer");
    }, [ActivityArray]);

    // const updatedActivity = { ...activityToEdit };
  };
  const onDelete = (id) => {
    console.log("ondelete function called, Acticity Id", id);
    setActivityArray((prev) => prev.filter((Activity) => Activity.id !== id));
    console.log("Activity deleted");
  };
  return (
    <>
      <Header />
      <Main createActivity={createActivity} />
      <Aside
        ActivityArray={ActivityArray}
        onEdit={onEdit}
        onDelete={onDelete}
      />
      <Footer />
    </>
  );
}
// Activity interface to outline the Activity object, it was moved outside the function App to be exportable to Aside

export default App;
