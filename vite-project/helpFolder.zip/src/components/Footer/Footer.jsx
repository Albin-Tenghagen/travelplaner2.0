function Footer() {
  return (
    <footer>
      <h4>Planerings Portal</h4>
    </footer>
  );
}

export default Footer;
