function FormHeading() {
  return <h3>Skapa en aktivitet för er resa!</h3>;
}
export default FormHeading;
